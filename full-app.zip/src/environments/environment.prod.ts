export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCjV4riA1uUdBVaa-FCOCnS8vBg3m_oCxs",
    authDomain: "ng-fitness-tracker-b2d9d.firebaseapp.com",
    databaseURL: "https://ng-fitness-tracker-b2d9d.firebaseio.com",
    projectId: "ng-fitness-tracker-b2d9d",
    storageBucket: "ng-fitness-tracker-b2d9d.appspot.com",
    messagingSenderId: "717099435859"
  }
};
